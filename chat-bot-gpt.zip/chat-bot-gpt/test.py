import os
import discord
import requests
from discord.ext import commands

# Replace "YOUR_DISCORD_BOT_TOKEN" and "YOUR_OPENAI_API_KEY" with your actual tokens
DISCORD_BOT_TOKEN = "MTA5ODU1NzU2NzU0ODAxMDUyNw.G8GN8X.rwXWJa9-OsXyzjQ-y9dk76UZfu9bWBztCIK3Lc"
OPENAI_API_KEY = "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"

# Replace "GPT_3_5_API_URL" with the actual GPT-3.5 API URL
CHATGPT_API_URL = "https://chat.openai.com/?model=text-davinci-002-render-sha"

# Set up the Discord bot
intents = discord.Intents.default()
intents.typing = False
intents.presences = False
bot = commands.Bot(command_prefix="!", intents=intents)

def chatgpt_request(prompt):
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }

    data = {
        # Replace "gpt-3.5-engine" with the actual GPT-3.5 engine name
        "engine": "gpt-3.5-engine",
        "prompt": prompt,
        "max_tokens": 100,
        "n": 1,
        "stop": None,
        "temperature": 0.8,
    }

    response = requests.post(CHATGPT_API_URL, headers=headers, json=data)
    response_data = response.json()
    return response_data["choices"][0]["text"].strip()

@bot.event
async def on_ready():
    print(f"{bot.user} has connected to Discord!")

@bot.command(name="ask")
async def ask_chatgpt(ctx, *, question):
    prompt = f"{question}\nAnswer:"
    response = chatgpt_request(prompt)
    await ctx.send(response)

# Run the bot
bot.run(DISCORD_BOT_TOKEN)
